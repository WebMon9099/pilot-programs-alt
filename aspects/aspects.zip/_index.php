<?php require_once('../checkuser.php'); ?>

<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Pat</title>
<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
<link rel="stylesheet" href="styles.css" />
<script src="lib/easeljs-NEXT.combined.js"></script>
<script src="lib/tweenjs-NEXT.min.js"></script>
<script src="lib/soundjs-NEXT.min.js"></script>
<script src="lib/preloadjs-NEXT.min.js"></script>

<script src="main.js"></script>

</head>

<body onLoad="Main();">

	<div id="title">
		<div id="tside">Error</div>
		<div id="tmid">
			<img src="images/logo.png" alt="logo" height="34" width="60">
		</div>
		<div id="tsider"></div>
	</div>

	<div id="mainb">
		<div id="loader">
			<img src="images/loading.gif" alt="ld" height="80" width="85">
		</div>
		<canvas id="test" width="980" height="950"></canvas>

	</div>
</body>
</html>
