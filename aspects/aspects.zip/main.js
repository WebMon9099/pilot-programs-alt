// JavaScript Document
var canvas;
var stage;
var sec=0,msec =0;

var proT,perT,timeT;
var loader;
var currentS = 0;
var inS;
var qState;

var targetSec =6;
var totalSec=120;


var totalC =0;
var errors=0,score=0;
var resultA;

var isGame = false;

var startCont,secondCont,gameCont;
var PlaneSp;
var pDir,pColor;

var questionsCount = 0;

function Main(){
	canvas = document.getElementById("test");
	stage = new createjs.Stage(canvas);
	optimizeForTouchAndScreens();
	stage.enableMouseOver(10);
	manifest = [

		{src: "images/btstart.png", id: "Bstart"},
		{src: "images/btstart-hover.png", id: "BHstart"},
		{src: "images/user-guide.png", id: "Bguide"},
		{src: "images/user-guide-hover.png", id: "BHguide"},
		{src: "images/bend2.png", id: "Bend"},
		{src: "images/bend2-hover.png", id: "BHend"},
		{src: "images/PAT_exam_logo.png", id: "Tlogo"},
		{src: "images/bttwo.png", id: "Btwo"},
		{src: "images/bttwo-hover.png", id: "BHtwo"},
		{src: "images/btfive.png", id: "Bfive"},
		{src: "images/btfive-hover.png", id: "BHfive"},
		{src: "images/btseven.png", id: "Bseven"},
		{src: "images/btseven-hover.png", id: "BHseven"},
		{src: "images/result.png", id: "Result"},
		{src: "images/Plan_0.png", id: "Plane0"},
		{src: "images/Plan_1.png", id: "Plane1"},
		{src: "images/Plan_2.png", id: "Plane2"},
		{src: "images/Plan_3.png", id: "Plane3"},
		{src: "images/audio.png", id: "Saudio"},
		{src: "images/grey.png", id: "Grey"},
		{src: "images/orange.png", id: "Orange"},
		{src: "sounds/blue.ogg", id: "SBlue"},
		{src: "sounds/red.ogg", id: "SRed"},
		{src: "sounds/right.ogg", id: "SRight"},
		{src: "sounds/left.ogg", id: "SLeft"}
	];
	proT = new createjs.Text("Loading....","600 20px Open Sans","#444");
	proT.y = 350;
	proT.x = 436;
	stage.addChild(proT);
	perT = new createjs.Text("Loading....","400 20px Open Sans","#444");
	perT.y = 350;
	perT.x = 476;
	stage.addChild(perT);
	loader = new createjs.LoadQueue(false);
	loader.installPlugin(createjs.Sound);
	createjs.Sound.alternateExtensions = ["mp3"];
	loader.addEventListener("progress", handleProgress);
	loader.addEventListener("complete", handleComplete);
	loader.loadManifest(manifest, true);

}


function handleProgress(){
	var progresPrecentage = Math.round(loader.progress*100);
	proT.text = String(progresPrecentage+"%");
	perT.text = String(" loaded");
	stage.update();
}
function optimizeForTouchAndScreens () {
	if (createjs.Touch.isSupported()) {
		createjs.Touch.enable(stage);
	}
}
function handleComplete(){
	loader.removeEventListener("progress", handleProgress);
	loader.removeEventListener("complete", handleComplete);
	stage.removeChild(proT);
	stage.removeChild(perT);

	qState = "no";
	isGame = false;
	var element = document.getElementById("loader");
	element.parentNode.removeChild(element);
	showStartScreen();
	//showSecondScreen();
	//createInterface();
	stage.update();
	startMain();


}
function showStartScreen(){
	document.getElementById('tside').innerHTML =  String("Aspects<span>Legacy</span>");
	document.getElementById('tsider').innerHTML =  String("Start of Exam");

	startCont = new createjs.Container();
	
	var sT = new createjs.Text("","bold 42px Montserrat","#444445");
	sT.text = String("Aspects");
	sT.y = 80;
	sT.x = 410;
	startCont.addChild(sT);


	var bmp = new createjs.Bitmap(loader.getResult("Bstart"));
	bmp.x =stage.canvas.width/2 - 380;
	bmp.y =400;
	bmp.name ="bstart";
	startCont.addChild(bmp);
	bmp.addEventListener('click',showSecondScreen);
	bmp.addEventListener('mouseover', mouseOverButton);
	bmp.addEventListener('mouseout', mouseOutButton);
	bmp.cursor = "pointer";

	bmp = new createjs.Bitmap(loader.getResult("Bguide"));
	bmp.x =stage.canvas.width/2 + 50;
	bmp.y =400;
	bmp.name ="bguide";
	startCont.addChild(bmp);
	bmp.addEventListener('click',showSecondScreen);
	bmp.addEventListener('mouseover', mouseOverButton);
	bmp.addEventListener('mouseout', mouseOutButton);
	bmp.cursor = "pointer";

	var by = new createjs.Text("by","24px Open Sans","#d3cccd");
	by.x = 280;
	by.y = 205;
	startCont.addChild(by);

	bmp = new createjs.Bitmap(loader.getResult("Tlogo"));
	bmp.regX =bmp.image.width/2;
	bmp.regY =bmp.image.height/2;
	bmp.x =stage.canvas.width/2;
	bmp.y =240;
	bmp.name ="Title";

	startCont.addChild(bmp);

	addPlaneSprite();

	stage.addChild(startCont);
}
function showSecondScreen(e){
	//alert("cc");
	e.target.removeEventListener('click',showSecondScreen);
	startCont.removeAllChildren();
	stage.removeChild(startCont);
	stage.update();
	secondCont = new createjs.Container();


	var bmp = new createjs.Bitmap(loader.getResult("Btwo"));
	bmp.regX =bmp.image.width/2;
	bmp.regY =bmp.image.height/2;
	bmp.x =stage.canvas.width/2;
	bmp.y =280;
	bmp.name ="btwo";

	bmp.addEventListener('click',chooseAndStart);
	bmp.addEventListener('mouseover', mouseOverButton);
	bmp.addEventListener('mouseout', mouseOutButton);
	secondCont.addChild(bmp);
	bmp.cursor = "pointer";


	bmp = new createjs.Bitmap(loader.getResult("Bfive"));
	bmp.regX =bmp.image.width/2;
	bmp.regY =bmp.image.height/2;
	bmp.x =stage.canvas.width/2;
	bmp.y =360;
	bmp.name ="bfive";

	bmp.addEventListener('click',chooseAndStart);
	bmp.addEventListener('mouseover', mouseOverButton);
	bmp.addEventListener('mouseout', mouseOutButton);
	secondCont.addChild(bmp);
	bmp.cursor = "pointer";

	bmp = new createjs.Bitmap(loader.getResult("Bseven"));
	bmp.regX =bmp.image.width/2;
	bmp.regY =bmp.image.height/2;
	bmp.x =stage.canvas.width/2;
	bmp.y =440;
	bmp.name ="bseven";

	bmp.addEventListener('click',chooseAndStart);
	bmp.addEventListener('mouseover', mouseOverButton);
	bmp.addEventListener('mouseout', mouseOutButton);
	secondCont.addChild(bmp);
	bmp.cursor = "pointer";
	var mT = new createjs.Text("","24px Montserrat","#444445");
	mT.text = String("Select your duration:");
	mT.y = 160;
	mT.x = 380;
	secondCont.addChild(mT);

	stage.addChild(secondCont);
	stage.update();

}
function chooseAndStart(e){
	var bname = String(e.target.name);
	switch(bname){
		case "btwo":
			totalSec=120;
		break;
		case "bfive":
			totalSec=300;
		break;
		case "bseven":
			totalSec=420;
		break;

	}
	secondCont.getChildByName("btwo").removeEventListener('click',chooseAndStart);
	secondCont.getChildByName("bfive").removeEventListener('click',chooseAndStart);
	secondCont.getChildByName("bseven").removeEventListener('click',chooseAndStart);
	createInterface();
}
function mouseOverButton(e){
	var bname = String(e.target.name);
	switch(bname){
		case "btwo":
			secondCont.getChildByName(bname).image=loader.getResult("BHtwo");
		break;
		case "bfive":
			secondCont.getChildByName(bname).image=loader.getResult("BHfive");
		break;
		case "bseven":
			secondCont.getChildByName(bname).image=loader.getResult("BHseven");
		break;
		case "bstart":
			startCont.getChildByName(bname).image=loader.getResult("BHstart");
		break;
		case "bguide":
			startCont.getChildByName(bname).image=loader.getResult("BHguide");
		break;
		case "bend":
			startCont.getChildByName(bname).image=loader.getResult("BHend");
		break;
	}
	// if(bname == 'btwo' || bname == 'bfive' || bname == 'bseven') {
	// 	secondCont.getChildByName(bname).removeEventListener('mouseover',mouseOutButton);
	// } else {
	// 	startCont.getChildByName(bname).removeEventListener('mouseover',mouseOutButton);
	// }
}
function mouseOutButton(e){
	var bname = String(e.target.name);
	switch(bname){
		case "btwo":
			secondCont.getChildByName(bname).image=loader.getResult("Btwo");
		break;
		case "bfive":
			secondCont.getChildByName(bname).image=loader.getResult("Bfive");
		break;
		case "bseven":
			secondCont.getChildByName(bname).image=loader.getResult("Bseven");
		break;
		case "bstart":
			startCont.getChildByName(bname).image=loader.getResult("Bstart");
		break;
		case "bguide":
			startCont.getChildByName(bname).image=loader.getResult("Bguide");
		break;
		case "bend":
			startCont.getChildByName(bname).image=loader.getResult("Bend");
		break;
	}
	// if(bname == 'btwo' || bname == 'bfive' || bname == 'bseven') {
	// 	secondCont.getChildByName(bname).removeEventListener('mouseout',mouseOutButton);
	// } else {
	// 	startCont.getChildByName(bname).removeEventListener('mouseout',mouseOutButton);
	// }
}
function createInterface(){

	//e.target.removeEventListener('click',createInterface);
	secondCont.removeAllChildren();
	stage.removeChild(secondCont);
	gameCont = new createjs.Container();


	stage.addChild(gameCont);

	qState = "no";
	pickQuestion();


	stage.update();
	isGame = true;



}
function pickQuestion(){
	inS =0;
	targetSec = 8;
	resultA = new Object;
	var sD = Math.floor(Math.random()*2);
	if(sD == 0){
		 pColor = String("Blue");

	}else{
		pColor = String("Red");
	}

	var cD = Math.floor(Math.random()*2);
	if(cD == 0){
		pDir = String("Right");

	}else{
		pDir = String("Left");
	}

	var bmp = addBmp("Saudio",500,300,true);
	gameCont.addChild(bmp);
	questionsCount++;
	playeAudioMain();
}
function startMain(){

	createjs.Ticker.setFPS(60);
	createjs.Ticker.addEventListener("tick",updateGame);

}
function updateGame(e){
	if(isGame){
	msec++;
	if(msec >= 60){
		msec =0;
		sec++;
		var rsec = totalSec-sec;
		var tStr = String(Math.floor(rsec/60)+ " minutes " +(rsec%60)+" seconds");
		document.getElementById('tsider').innerHTML =  String(tStr);

		if(qState == "yes"){
			targetSec--;
			timeT.text = String(targetSec+" second(s) remaining!");
			if(targetSec <= 0){
				qState = "no";
				clearGameWindow();
				checkAnswer();

			}

		}
	}
	if(sec > totalSec){
		isGame = false;
		sec =0;
		qState = "no";
		clearGameWindow();
		checkAnswer();
		gameOver();
	}
	}
	stage.update();
}

function playAgain(e){
	e.target.removeEventListener('click',playAgain);


}



//color audi
function playeAudioMain(){
	if(inS == 0){
		var aName = String("S"+pColor);
	}else{
		aName = String("S"+pDir);
	}

	var instance = createjs.Sound.play(aName);
	instance.on("complete", createjs.proxy(this.handleCompleteSoundC, this));
  	instance.volume = 1;


}
function handleCompleteSoundC(){
	inS++;
	if(inS < 2){

		playeAudioMain();
	}else{
			inS =0;
			gameCont.removeAllChildren();
			showImages();

		}

}

function showImages(){

	var isDone = false;
	var allFrame = PlaneSp.animations;

	var selFrame = new Array();
	while(!isDone){
		totalC =0;
		var rD = Math.floor(Math.random()*allFrame.length);
		var rName = String(allFrame[rD]);
		if(selFrame.indexOf(rName) == -1){
			selFrame.push(rName);
		}
		if(selFrame.length >= 4){
			var tStr = String(pColor+pDir);
			for(var i =0;i<selFrame.length;i++){
				var sStr = String(selFrame[i]);
				sStr = sStr.slice(0,-1);

				if(sStr == tStr){
					totalC++;
					isDone = true;

				}

			}
			if(!isDone){
				selFrame = [];
			}

		}

	}
	if(isDone){
	i =0;
	for(var r =0; r<2;r++){
		for(var c=0; c<2;c++){
			var pFr = String(selFrame[i]);
			var cFr = String(pFr.slice(0,-1));

			var grayC =  addBmp("Grey",0,0,true,0.75);
			gameCont.addChild(grayC);
			grayC.x = stage.canvas.width/2 + c*(grayC.image.width*0.75) - grayC.image.width/2*0.75;
			grayC.y = 185 + r*(grayC.image.height*0.75);
			grayC.name = String(cFr+String(r)+String(c));
			grayC.type = cFr;
			grayC.cursor = "pointer";
			grayC.addEventListener("click",selectPlane);

			var OrangeC =  addBmp("Orange",0,0,true, 0.75);
			gameCont.addChild(OrangeC);
			OrangeC.x = stage.canvas.width/2 + c*(OrangeC.image.width*0.75) - OrangeC.image.width/2*0.75;
			OrangeC.y = 185 + r*(OrangeC.image.height*0.75);
			OrangeC.name = String(cFr+String(r)+String(c)+"o");
			OrangeC.visible = false;
			OrangeC.addEventListener("click", deselectPlane);

			var planeC =  new createjs.Sprite(PlaneSp,pFr);
			gameCont.addChild(planeC);
			//stage.addChild(planeC);
			// planeC.regX = planeC.getBounds().image.width/2;
			// planeC.regY = planeC.getBounds().image.height/2;
			planeC.scaleX = 0.75;
			planeC.scaleY = 0.75;
			// planeC.x = 175 + c*386*0.75;
			// planeC.y = r*(planeC.getBounds().height*0.75-90)+30;
			planeC.regX = planeC.getBounds().width / 2;
			planeC.regY = planeC.getBounds().height / 2;

			planeC.x = stage.canvas.width/2 + c*(OrangeC.image.width*0.75) - OrangeC.image.width/2*0.75;
			planeC.y = 185 + r*(OrangeC.image.height*0.75);

			pFr = pFr.slice(0,-1);
			planeC.name = pFr;


			i++

		}

	}
	}
	selFrame=[];

	qState = "yes";
	//var bmp = addBmp("Sback",394,0,false);
	//gameCont.addChild(bmp);
	timeT = new createjs.Text("Loading....","400 20px Open Sans","#313131");
	timeT.y = 12;
	timeT.x = 385;

	gameCont.addChild(timeT);
}

function selectPlane(e){
	var tbP = e.target;
	var tName = String(tbP.name);
	var tType = String(tbP.type);

	tName = String(tName+"o");

	gameCont.getChildByName(tName).visible = true;
	var tStr = String(pColor+pDir);
	if(tType == tStr){
		resultA[tName] = 1;
	}else{
		resultA[tName] = 0;
	}

	if(Object.keys(resultA).length >=  4){
		qState = "no";
		clearGameWindow();
		checkAnswer();
	}
}
function deselectPlane(e){
	var tbP = e.target;
	tbP.visible = false;

	var tName = String(tbP.name);
	
	delete resultA[tName];

	if(Object.keys(resultA).length >=  4){
		qState = "no";
		clearGameWindow();
		checkAnswer();
	}
}
function checkAnswer(){

	if(Object.keys(resultA).length > 0){
		if(Object.values(resultA).indexOf(0) == -1){
			var total =0;
			for(var i =0; i<Object.values(resultA).length;i++){
				total += Object.values(resultA)[i];
			}
			if(total == totalC){
				score++;
			}else{
				errors++;
			}
		}else{
			errors++;
		}
	}else{
		errors++;

	}
	document.getElementById('tsiderx').innerHTML =  String("Score: "+score);
	pickQuestion();

}
//audio number

function gameOver(){

	msec =0;
	sec=0;
	createjs.Sound.stop();
	gameCont.removeAllChildren();
	showEndScreen();
}
function showEndScreen(){

	document.getElementById('tside').innerHTML =  String("Aspects<span>Legacy</span>");
	document.getElementById('tsider').innerHTML =  String("End of Exam");
	startCont = new createjs.Container();

	var bmp = new createjs.Bitmap(loader.getResult("Result"));
	bmp.regX =bmp.image.width/2;
	bmp.regY =bmp.image.height/2;
	bmp.x =stage.canvas.width/2;
	bmp.y =150;
	bmp.name ="result";
	startCont.addChild(bmp);

	bmp = new createjs.Bitmap(loader.getResult("Bend"));
	bmp.regX =bmp.image.width/2;
	bmp.regY =bmp.image.height/2;
	bmp.x =stage.canvas.width/2;
	bmp.y =480;
	bmp.name ="bend";
	bmp.cursor = "pointer";
	startCont.addChild(bmp);
	bmp.addEventListener('click',startAgain);
	bmp.addEventListener('mouseover', mouseOverButton);
	bmp.addEventListener('mouseout', mouseOutButton);

	var mT = new createjs.Text("","16px Open Sans","#c4c4c4");
	mT.text = String(`(${score} correct answers out of ${questionsCount} questions)`);
	mT.y = 275;
	mT.x = 355;
	startCont.addChild(mT);


	var eT = new createjs.Text("","68px Open Sans","#494949");
	var _percent = score / questionsCount * 100;
	eT.text = String(_percent.toFixed(0));
	eT.y = 160;
	if(_percent < 10) {
		eT.x = 475;
	} else if(_percent > 9 && _percent < 100) {
		eT.x = 435;
	} else if(_percent > 99 ){
		eT.x = 400;
	}
	startCont.addChild(eT);

	stage.addChild(startCont);
	//var accuracy = giveAresult();
	//var accuracy2 = giveAresultd();
	saveLoaded();
	errors =0;
	score =0;
	questionsCount = 0;
	stage.update();
}
function startAgain(e){
	e.target.removeEventListener('click',startAgain);
	startCont.removeAllChildren();
	stage.removeChild(startCont);
	showStartScreen();
	stage.update();

}
function addPlaneSprite(){

	var data ={
		"framerate":24,
		"images":["images/Plan_0.png", "images/Plan_1.png", "images/Plan_2.png", "images/Plan_3.png"],
		"frames":[
			[0, 0, 386, 373, 0, 0, 0],
			[387, 0, 386, 373, 0, 0, 0],
			[773, 0, 386, 373, 0, 0, 0],
			[0, 374, 386, 373, 0, 0, 0],
			[387, 374, 386, 373, 0, 0, 0],
			[773, 374, 386, 373, 0, 0, 0],
			[0, 747, 386, 373, 0, 0, 0],
			[387, 747, 386, 373, 0, 0, 0],
			[773, 747, 386, 373, 0, 0, 0],
			[0, 0, 386, 373, 1, 0, 0],
			[387, 0, 386, 373, 1, 0, 0],
			[773, 0, 386, 373, 1, 0, 0],
			[0, 374, 386, 373, 1, 0, 0],
			[387, 374, 386, 373, 1, 0, 0],
			[773, 374, 386, 373, 1, 0, 0],
			[0, 747, 386, 373, 1, 0, 0],
			[387, 747, 386, 373, 1, 0, 0],
			[773, 747, 386, 373, 1, 0, 0],
			[0, 0, 386, 373, 2, 0, 0],
			[387, 0, 386, 373, 2, 0, 0],
			[773, 0, 386, 373, 2, 0, 0],
			[0, 374, 386, 373, 2, 0, 0],
			[387, 374, 386, 373, 2, 0, 0],
			[773, 374, 386, 373, 2, 0, 0],
			[0, 747, 386, 373, 2, 0, 0],
			[387, 747, 386, 373, 2, 0, 0],
			[773, 747, 386, 373, 2, 0, 0],
			[0, 0, 386, 373, 3, 0, 0],
			[387, 0, 386, 373, 3, 0, 0],
			[773, 0, 386, 373, 3, 0, 0],
		],
		"animations":{
			"RedRight5": {"speed": 1, "frames": [26]},
			"BlueLeft1": {"speed": 1, "frames": [0]},
			"RedRight8": {"speed": 1, "frames": [29]},
			"BlueLeft5": {"speed": 1, "frames": [4]},
			"BlueRight3": {"speed": 1, "frames": [9]},
			"BlueLeft4": {"speed": 1, "frames": [3]},
			"BlueRight4": {"speed": 1, "frames": [10]},
			"RedLeft1": {"speed": 1, "frames": [15]},
			"BlueRight8": {"speed": 1, "frames": [14]},
			"BlueLeft7": {"speed": 1, "frames": [6]},
			"RedRight1": {"speed": 1, "frames": [22]},
			"BlueRight7": {"speed": 1, "frames": [13]},
			"RedLeft3": {"speed": 1, "frames": [17]},
			"RedLeft2": {"speed": 1, "frames": [16]},
			"BlueRight1": {"speed": 1, "frames": [7]},
			"RedLeft6": {"speed": 1, "frames": [20]},
			"BlueRight6": {"speed": 1, "frames": [12]},
			"BlueLeft6": {"speed": 1, "frames": [5]},
			"BlueRight2": {"speed": 1, "frames": [8]},
			"RedLeft4": {"speed": 1, "frames": [18]},
			"RedRight4": {"speed": 1, "frames": [25]},
			"BlueRight5": {"speed": 1, "frames": [11]},
			"BlueLeft3": {"speed": 1, "frames": [2]},
			"RedRight7": {"speed": 1, "frames": [28]},
			"RedRight2": {"speed": 1, "frames": [23]},
			"RedLeft7": {"speed": 1, "frames": [21]},
			"BlueLeft2": {"speed": 1, "frames": [1]},
			"RedLeft5": {"speed": 1, "frames": [19]},
			"RedRight3": {"speed": 1, "frames": [24]},
			"RedRight6": {"speed": 1, "frames": [27]}
		}
	};
	PlaneSp = new createjs.SpriteSheet(data);
}
//save the score
function saveLoaded(){
	// Create our XMLHttpRequest object
    var hr = new XMLHttpRequest();

	var datastring ="";

	datastring += "aspectErrors"+"="+errors+"&";
	datastring += "duration"+"="+totalSec;


  	 hr.open('POST','saveASScore.php');
    // Set content type header information for sending url encoded variables in the request
    hr.setRequestHeader("Content-type","application/x-www-form-urlencoded");

    // Access the onreadystatechange event for the XMLHttpRequest object
    hr.onreadystatechange = function() {
	    if(hr.readyState == 4 && hr.status == 200) {
		  	 var return_data =hr.responseText;
			//alert(return_data);



	    }
    }
    // Send the data to PHP now... and wait for response to update the status div
    hr.send(datastring); // Actually execute the re


}
function addBmp(bname,tx,ty,isR,scale=1){
	var bmp = new createjs.Bitmap(loader.getResult(bname));
	if(isR){
		bmp.regX = bmp.image.width/2;
		bmp.regY = bmp.image.height/2;
	}
	bmp.scaleX = scale;
	bmp.scaleY = scale;
	bmp.y = ty;
	bmp.x = tx;
	return bmp;

}

function clearGameWindow(){
	for(var i =0; i<gameCont.numChildren;i++){
		if(gameCont.getChildAt(i).hasEventListener("click")){
			gameCont.getChildAt(i).removeEventListener("click",selectPlane);
		}

	}
	gameCont.removeAllChildren();
}